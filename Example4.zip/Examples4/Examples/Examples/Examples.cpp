﻿// Examples.cpp : Определяет точку входа для приложения.
//

#include "framework.h"
#include "Examples.h"

#include "D3D.h"
#define MAX_LOADSTRING 100

// Глобальные переменные:
HWND m_hwnd;
HANDLE hTread;
BOOL ExitRender = TRUE;//Выйти из потока рендеринга
DWORD dwTreadId;
HINSTANCE hInst;                                // текущий экземпляр
WCHAR szTitle[MAX_LOADSTRING];                  // Текст строки заголовка
WCHAR szWindowClass[MAX_LOADSTRING];            // имя класса главного окна
D3D* D3d = NULL;
FLOAT time0 = 0;
//переменные для буфера объекта
VERTEX Triangle[4];
unsigned long Indices[4];
D3D11_BUFFER_DESC vertexBufferDesc, indexBufferDesc;
D3D11_SUBRESOURCE_DATA vertexData, indexData;
ID3D11Buffer* VBuffer = NULL;
ID3D11Buffer* IBuffer = NULL;
ID3D11Buffer* CBuffer0 = NULL;
//переменные шейдеров
ID3D11VertexShader* VShader=NULL;
ID3D11InputLayout* Layout=NULL;
ID3D11PixelShader* PShader=NULL;
//переменные состояния
ID3D11RasterizerState* Rasterstate=NULL;
ID3D11DepthStencilState* Depthstencilstate=NULL;
//Текстуры
ID3D11ShaderResourceView* Texture=NULL;
// Отправить объявления функций, включенных в этот модуль кода:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
    // Инициализация глобальных строк
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_EXAMPLES, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);
    // Выполнить инициализацию приложения:
    if (!InitInstance(hInstance, nCmdShow))
    {
        return FALSE;
    }
    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_EXAMPLES));

    MSG msg;
    // Цикл основного сообщения:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    StopTread();
    CloseHandle(hTread);
    delete D3d;
    return (int)msg.wParam;
}
//
//  ФУНКЦИЯ: MyRegisterClass()
//
//  ЦЕЛЬ: Регистрирует класс окна.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_EXAMPLES));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_EXAMPLES);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
    return RegisterClassExW(&wcex);
}
//
//   ФУНКЦИЯ: InitInstance(HINSTANCE, int)
//
//   ЦЕЛЬ: Сохраняет маркер экземпляра и создает главное окно
//
//   КОММЕНТАРИИ:
//
//        В этой функции маркер экземпляра сохраняется в глобальной переменной, а также
//        создается и выводится главное окно программы.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_SYSTEM_AWARE);
    hInst = hInstance; // Сохранить маркер экземпляра в глобальной переменной 

    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);
    if (!hWnd)
    {
        return FALSE;
    }
    m_hwnd = hWnd;
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    D3d = new D3D();
    RECT rect = { 0 };
    GetWindowRect(hWnd, &rect);

    if(FAILED(D3d->Initialize((UINT)(rect.right - rect.left), (UINT)(rect.bottom - rect.top), TRUE, hWnd, FALSE))) return FALSE;
    Triangle[0].pos.x = -0.9f;
    Triangle[0].pos.y = 0.9f;
    Triangle[0].color = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
    Triangle[0].tex.x = 0.0;
    Triangle[0].tex.y = 0.0;
    Triangle[1].pos.x = -0.9f;
    Triangle[1].pos.y = -0.9f;
    Triangle[1].color = XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f);
    Triangle[1].tex.x = 0.0;
    Triangle[1].tex.y = 1.0;
    Triangle[2].pos.x = 0.9f;
    Triangle[2].pos.y = 0.9f;
    Triangle[2].color = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);
    Triangle[2].tex.x = 1.0;
    Triangle[2].tex.y = 0.0;
    Triangle[3].pos.x = 0.9f;
    Triangle[3].pos.y = -0.9f;
    Triangle[3].color = XMFLOAT4(1.0f, 1.0f, 0.0f, 1.0f);
    Triangle[3].tex.x = 1.0;
    Triangle[3].tex.y = 1.0;
    Indices[0] = 0;
    Indices[1] = 1;
    Indices[2] = 2;
    Indices[3] = 3;
    // Set up the description of the dynamic vertex buffer.
    vertexBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
    vertexBufferDesc.ByteWidth = sizeof(VERTEX) * 4;
    vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    vertexBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    vertexBufferDesc.MiscFlags = 0;
    vertexBufferDesc.StructureByteStride = 0;
    // Give the subresource structure a pointer to the vertex data.
    vertexData.pSysMem = Triangle;
    vertexData.SysMemPitch = 0;
    vertexData.SysMemSlicePitch = 0;
    // Set up the description of the static index buffer.
    indexBufferDesc.Usage = D3D11_USAGE_DEFAULT;
    indexBufferDesc.ByteWidth = sizeof(unsigned long) * 4;
    indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
    indexBufferDesc.CPUAccessFlags = 0;
    indexBufferDesc.MiscFlags = 0;
    indexBufferDesc.StructureByteStride = 0;
    // Give the subresource structure a pointer to the index data.
    indexData.pSysMem = Indices;
    indexData.SysMemPitch = 0;
    indexData.SysMemSlicePitch = 0;
    if (FAILED(D3d->device->CreateBuffer(&vertexBufferDesc, &vertexData, &VBuffer))) return FALSE;
    if (FAILED(D3d->device->CreateBuffer(&indexBufferDesc, &indexData, &IBuffer))) return FALSE;
    //Загрузка вершинного шейдера
    ID3D10Blob* errorMessage=NULL;
    ID3D10Blob* vertexShaderBuffer=NULL;
    if (FAILED(D3DReadFileToBlob(L"VSEx2.cso", &vertexShaderBuffer))) return FALSE;
    // Create the vertex shader from the buffer.
    if (FAILED(D3d->device->CreateVertexShader(vertexShaderBuffer->GetBufferPointer(), vertexShaderBuffer->GetBufferSize(), NULL,
        &VShader))) return FALSE;
    D3D11_INPUT_ELEMENT_DESC* desc = NULL;
    UINT numElements;
    numElements = 3;
    desc = new D3D11_INPUT_ELEMENT_DESC[numElements];
    desc[0].SemanticName = "POSITION";
    desc[0].SemanticIndex = 0;
    desc[0].Format = DXGI_FORMAT_R32G32_FLOAT; 
    desc[0].InputSlot = 0;
    desc[0].AlignedByteOffset = 0;
    desc[0].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
    desc[0].InstanceDataStepRate = 0;

    desc[1].SemanticName = "COLOR";
    desc[1].SemanticIndex = 0;
    desc[1].Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    desc[1].InputSlot = 0;
    desc[1].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
    desc[1].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
    desc[1].InstanceDataStepRate = 0;
    
    desc[2].SemanticName = "TEXCOORD";
    desc[2].SemanticIndex = 0;
    desc[2].Format = DXGI_FORMAT_R32G32_FLOAT;
    desc[2].InputSlot = 0;
    desc[2].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
    desc[2].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
    desc[2].InstanceDataStepRate = 0;
    HRESULT result = D3d->device->CreateInputLayout(desc, numElements, vertexShaderBuffer->GetBufferPointer(),
        vertexShaderBuffer->GetBufferSize(), &Layout);
    delete[] desc;
    ReleaseCOM(vertexShaderBuffer);
    
    if (FAILED(result)) return FALSE;
    //Загрузка пиксельного шейдера
    ID3D10Blob* pixelShaderBuffer = NULL;
    if(FAILED(D3DReadFileToBlob(L"PSEx2.cso", &pixelShaderBuffer))) return FALSE;
    result = D3d->device->CreatePixelShader(pixelShaderBuffer->GetBufferPointer(), pixelShaderBuffer->GetBufferSize(), NULL,
        &PShader);
    ReleaseCOM(pixelShaderBuffer);
    if (FAILED(result)) return FALSE;
    D3D11_RASTERIZER_DESC descr;
    descr.AntialiasedLineEnable = FALSE;
    descr.CullMode = D3D11_CULL_NONE;
    descr.DepthBias = 0;
    descr.DepthBiasClamp = 0.0f;
    descr.DepthClipEnable = 1;
    descr.FillMode = D3D11_FILL_SOLID;
    descr.FrontCounterClockwise = 0;
    descr.MultisampleEnable = 0;
    descr.ScissorEnable = 0;
    descr.SlopeScaledDepthBias = 0.0f;
    if (FAILED(D3d->device->CreateRasterizerState(&descr, &Rasterstate))) return FALSE;
    D3D11_DEPTH_STENCIL_DESC descz;
    descz.DepthEnable = 0;
    descz.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    descz.DepthFunc = D3D11_COMPARISON_LESS;
    descz.StencilEnable = 0;
    descz.StencilReadMask = 255;
    descz.StencilWriteMask = 255;
    descz.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
    descz.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_INCR;
    descz.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    descz.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
    descz.BackFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
    descz.BackFace.StencilDepthFailOp = D3D11_STENCIL_OP_DECR;
    descz.BackFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    descz.BackFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
    if (FAILED(D3d->device->CreateDepthStencilState(&descz, &Depthstencilstate))) return FALSE;
    
    XMFLOAT4 data = XMFLOAT4(0,0,0,0);
    D3D11_BUFFER_DESC BufferDesc;
    D3D11_SUBRESOURCE_DATA Data;
    BufferDesc.Usage = D3D11_USAGE_DYNAMIC;
    BufferDesc.ByteWidth = sizeof(XMFLOAT4) * 1;
    BufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    BufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    BufferDesc.MiscFlags = 0;
    BufferDesc.StructureByteStride = 0;

    Data.pSysMem = &data;
    Data.SysMemPitch = 0;
    Data.SysMemSlicePitch = 0;

    if(FAILED(D3d->device->CreateBuffer(&BufferDesc, &Data, &CBuffer0))) return FALSE;
    //Загрузка текстуры
    HRESULT hr;

    TexMetadata imageMetadata;
    ScratchImage* image = new ScratchImage();

    hr = LoadFromDDSFile(L"Brick_D.dds", DDS_FLAGS_NONE, &imageMetadata, *image);
    hr = CreateShaderResourceView(D3d->device, image->GetImages(), image->GetImageCount(), imageMetadata, &Texture);
    delete image;
    if (FAILED(hr)) return FALSE;
    
    StartTread();//включить рендеринг
    return TRUE;
}
//
//  ФУНКЦИЯ: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  ЦЕЛЬ: Обрабатывает сообщения в главном окне.
//
//  WM_COMMAND  - обработать меню приложения
//  WM_PAINT    - Отрисовка главного окна
//  WM_DESTROY  - отправить сообщение о выходе и вернуться
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Разобрать выбор в меню:
        switch (wmId)
        {
        case IDM_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY:
        StopTread();
        CloseHandle(hTread);
        ReleaseCOM(VBuffer);
        ReleaseCOM(IBuffer);
        ReleaseCOM(CBuffer0);
        ReleaseCOM(VShader);
        ReleaseCOM(Layout);
        ReleaseCOM(PShader);
        ReleaseCOM(Rasterstate);
        ReleaseCOM(Depthstencilstate);
        ReleaseCOM(Texture);
        ReleaseMY(D3d);
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
// Обработчик сообщений для окна "О программе".
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
//Остановить поток рендеринга
VOID StopTread()
{
    if (hTread == NULL) return;
    if (ExitRender)	return;
    ExitRender = TRUE;
    WaitForSingleObject(hTread, INFINITE); // ждём, когда поток реально завершится
    CloseHandle(hTread); // закрываем хендл
    hTread = NULL;
}
//Запустить поток рендеринга
VOID StartTread()
{
    if (hTread != NULL) return;
    if (!ExitRender) return;
    ExitRender = FALSE;
    hTread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Render, &ExitRender, 0, &dwTreadId);
}
//Поток рендеринга
DWORD WINAPI Render(LPVOID pNeedStop)
{
    while (!(*(bool*)pNeedStop))
    {
        XMFLOAT4 color = XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
        D3d->BeginScene(&color);
        D3d->deviceContext->RSSetState(Rasterstate);
        D3d->deviceContext->OMSetDepthStencilState(Depthstencilstate, 0);
        unsigned int stride, offset;
        stride = sizeof(VERTEX);
        offset = 0;
        D3d->deviceContext->IASetVertexBuffers(0, 1, &VBuffer, &stride, &offset);
        D3d->deviceContext->IASetIndexBuffer(IBuffer, DXGI_FORMAT_R32_UINT, 0);
        //Заполним и установим константный буфер
        D3D11_MAPPED_SUBRESOURCE mappedResource;
        D3d->deviceContext->Map(CBuffer0, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
        XMFLOAT4* temp = (XMFLOAT4*)mappedResource.pData;
        temp[0].x = time0/60.0f;// time;
        D3d->deviceContext->Unmap(CBuffer0, 0);
        time0++;
        D3d->deviceContext->VSSetConstantBuffers(0, 1, &CBuffer0);
        D3d->deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
        D3d->deviceContext->IASetInputLayout(Layout);
        D3d->deviceContext->VSSetShader(VShader, NULL, 0);
        D3d->deviceContext->PSSetShader(PShader, NULL, 0);
        D3d->deviceContext->PSSetShaderResources(0, 1, &Texture);
        D3d->deviceContext->DrawIndexed(4, 0, 0);
        
        D3d->EndScene();
    }
    return 0;
}